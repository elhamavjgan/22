alert('hello guys')
console.log('console')
document.write('here is me js class')